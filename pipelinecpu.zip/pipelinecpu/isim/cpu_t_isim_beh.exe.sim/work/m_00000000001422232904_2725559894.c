/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "E:/ISE_Project/pipelinecpu/source/alu.v";
static unsigned int ng1[] = {0U, 0U};
static unsigned int ng2[] = {1U, 0U};
static unsigned int ng3[] = {2U, 0U};
static unsigned int ng4[] = {3U, 0U};
static unsigned int ng5[] = {4U, 0U};
static unsigned int ng6[] = {5U, 0U};
static unsigned int ng7[] = {6U, 0U};
static unsigned int ng8[] = {4294967295U, 4294967295U};



static void Cont_28_0(char *t0)
{
    char t3[8];
    char t4[8];
    char t6[8];
    char t36[8];
    char t41[8];
    char t42[8];
    char t44[8];
    char t74[8];
    char t109[8];
    char t110[8];
    char t113[8];
    char t143[8];
    char t174[8];
    char t175[8];
    char t178[8];
    char t208[8];
    char t225[8];
    char t226[8];
    char t229[8];
    char t259[8];
    char t264[8];
    char t265[8];
    char t267[8];
    char t297[8];
    char t302[8];
    char t303[8];
    char t305[8];
    char t335[8];
    char *t1;
    char *t2;
    char *t5;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    char *t28;
    char *t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    char *t33;
    char *t34;
    char *t35;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    char *t43;
    char *t45;
    char *t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    char *t59;
    char *t60;
    unsigned int t61;
    unsigned int t62;
    unsigned int t63;
    unsigned int t64;
    unsigned int t65;
    char *t66;
    char *t67;
    unsigned int t68;
    unsigned int t69;
    unsigned int t70;
    char *t71;
    char *t72;
    char *t73;
    unsigned int t75;
    unsigned int t76;
    unsigned int t77;
    char *t78;
    char *t79;
    unsigned int t80;
    unsigned int t81;
    unsigned int t82;
    unsigned int t83;
    unsigned int t84;
    unsigned int t85;
    unsigned int t86;
    char *t87;
    char *t88;
    unsigned int t89;
    unsigned int t90;
    unsigned int t91;
    unsigned int t92;
    unsigned int t93;
    unsigned int t94;
    unsigned int t95;
    unsigned int t96;
    int t97;
    int t98;
    unsigned int t99;
    unsigned int t100;
    unsigned int t101;
    unsigned int t102;
    unsigned int t103;
    unsigned int t104;
    unsigned int t105;
    unsigned int t106;
    unsigned int t107;
    unsigned int t108;
    char *t111;
    char *t112;
    char *t114;
    char *t115;
    unsigned int t116;
    unsigned int t117;
    unsigned int t118;
    unsigned int t119;
    unsigned int t120;
    unsigned int t121;
    unsigned int t122;
    unsigned int t123;
    unsigned int t124;
    unsigned int t125;
    unsigned int t126;
    unsigned int t127;
    char *t128;
    char *t129;
    unsigned int t130;
    unsigned int t131;
    unsigned int t132;
    unsigned int t133;
    unsigned int t134;
    char *t135;
    char *t136;
    unsigned int t137;
    unsigned int t138;
    unsigned int t139;
    char *t140;
    char *t141;
    char *t142;
    unsigned int t144;
    unsigned int t145;
    unsigned int t146;
    char *t147;
    char *t148;
    unsigned int t149;
    unsigned int t150;
    unsigned int t151;
    unsigned int t152;
    unsigned int t153;
    unsigned int t154;
    unsigned int t155;
    char *t156;
    char *t157;
    unsigned int t158;
    unsigned int t159;
    unsigned int t160;
    int t161;
    unsigned int t162;
    unsigned int t163;
    unsigned int t164;
    int t165;
    unsigned int t166;
    unsigned int t167;
    unsigned int t168;
    unsigned int t169;
    unsigned int t170;
    unsigned int t171;
    unsigned int t172;
    unsigned int t173;
    char *t176;
    char *t177;
    char *t179;
    char *t180;
    unsigned int t181;
    unsigned int t182;
    unsigned int t183;
    unsigned int t184;
    unsigned int t185;
    unsigned int t186;
    unsigned int t187;
    unsigned int t188;
    unsigned int t189;
    unsigned int t190;
    unsigned int t191;
    unsigned int t192;
    char *t193;
    char *t194;
    unsigned int t195;
    unsigned int t196;
    unsigned int t197;
    unsigned int t198;
    unsigned int t199;
    char *t200;
    char *t201;
    unsigned int t202;
    unsigned int t203;
    unsigned int t204;
    char *t205;
    char *t206;
    char *t207;
    unsigned int t209;
    unsigned int t210;
    unsigned int t211;
    char *t212;
    char *t213;
    unsigned int t214;
    unsigned int t215;
    unsigned int t216;
    unsigned int t217;
    unsigned int t218;
    unsigned int t219;
    unsigned int t220;
    unsigned int t221;
    unsigned int t222;
    unsigned int t223;
    unsigned int t224;
    char *t227;
    char *t228;
    char *t230;
    char *t231;
    unsigned int t232;
    unsigned int t233;
    unsigned int t234;
    unsigned int t235;
    unsigned int t236;
    unsigned int t237;
    unsigned int t238;
    unsigned int t239;
    unsigned int t240;
    unsigned int t241;
    unsigned int t242;
    unsigned int t243;
    char *t244;
    char *t245;
    unsigned int t246;
    unsigned int t247;
    unsigned int t248;
    unsigned int t249;
    unsigned int t250;
    char *t251;
    char *t252;
    unsigned int t253;
    unsigned int t254;
    unsigned int t255;
    char *t256;
    char *t257;
    char *t258;
    unsigned int t260;
    unsigned int t261;
    unsigned int t262;
    unsigned int t263;
    char *t266;
    char *t268;
    char *t269;
    unsigned int t270;
    unsigned int t271;
    unsigned int t272;
    unsigned int t273;
    unsigned int t274;
    unsigned int t275;
    unsigned int t276;
    unsigned int t277;
    unsigned int t278;
    unsigned int t279;
    unsigned int t280;
    unsigned int t281;
    char *t282;
    char *t283;
    unsigned int t284;
    unsigned int t285;
    unsigned int t286;
    unsigned int t287;
    unsigned int t288;
    char *t289;
    char *t290;
    unsigned int t291;
    unsigned int t292;
    unsigned int t293;
    char *t294;
    char *t295;
    char *t296;
    unsigned int t298;
    unsigned int t299;
    unsigned int t300;
    unsigned int t301;
    char *t304;
    char *t306;
    char *t307;
    unsigned int t308;
    unsigned int t309;
    unsigned int t310;
    unsigned int t311;
    unsigned int t312;
    unsigned int t313;
    unsigned int t314;
    unsigned int t315;
    unsigned int t316;
    unsigned int t317;
    unsigned int t318;
    unsigned int t319;
    char *t320;
    char *t321;
    unsigned int t322;
    unsigned int t323;
    unsigned int t324;
    unsigned int t325;
    unsigned int t326;
    char *t327;
    char *t328;
    unsigned int t329;
    unsigned int t330;
    unsigned int t331;
    char *t332;
    char *t333;
    char *t334;
    unsigned int t336;
    unsigned int t337;
    unsigned int t338;
    unsigned int t339;
    char *t340;
    char *t341;
    char *t342;
    char *t343;
    char *t344;
    char *t345;

LAB0:    t1 = (t0 + 2688U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(28, ng0);
    t2 = (t0 + 1368U);
    t5 = *((char **)t2);
    t2 = ((char*)((ng1)));
    memset(t6, 0, 8);
    t7 = (t5 + 4);
    t8 = (t2 + 4);
    t9 = *((unsigned int *)t5);
    t10 = *((unsigned int *)t2);
    t11 = (t9 ^ t10);
    t12 = *((unsigned int *)t7);
    t13 = *((unsigned int *)t8);
    t14 = (t12 ^ t13);
    t15 = (t11 | t14);
    t16 = *((unsigned int *)t7);
    t17 = *((unsigned int *)t8);
    t18 = (t16 | t17);
    t19 = (~(t18));
    t20 = (t15 & t19);
    if (t20 != 0)
        goto LAB7;

LAB4:    if (t18 != 0)
        goto LAB6;

LAB5:    *((unsigned int *)t6) = 1;

LAB7:    memset(t4, 0, 8);
    t22 = (t6 + 4);
    t23 = *((unsigned int *)t22);
    t24 = (~(t23));
    t25 = *((unsigned int *)t6);
    t26 = (t25 & t24);
    t27 = (t26 & 1U);
    if (t27 != 0)
        goto LAB8;

LAB9:    if (*((unsigned int *)t22) != 0)
        goto LAB10;

LAB11:    t29 = (t4 + 4);
    t30 = *((unsigned int *)t4);
    t31 = *((unsigned int *)t29);
    t32 = (t30 || t31);
    if (t32 > 0)
        goto LAB12;

LAB13:    t37 = *((unsigned int *)t4);
    t38 = (~(t37));
    t39 = *((unsigned int *)t29);
    t40 = (t38 || t39);
    if (t40 > 0)
        goto LAB14;

LAB15:    if (*((unsigned int *)t29) > 0)
        goto LAB16;

LAB17:    if (*((unsigned int *)t4) > 0)
        goto LAB18;

LAB19:    memcpy(t3, t41, 8);

LAB20:    t340 = (t0 + 3088);
    t341 = (t340 + 56U);
    t342 = *((char **)t341);
    t343 = (t342 + 56U);
    t344 = *((char **)t343);
    memcpy(t344, t3, 8);
    xsi_driver_vfirst_trans(t340, 0, 31);
    t345 = (t0 + 3008);
    *((int *)t345) = 1;

LAB1:    return;
LAB6:    t21 = (t6 + 4);
    *((unsigned int *)t6) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB7;

LAB8:    *((unsigned int *)t4) = 1;
    goto LAB11;

LAB10:    t28 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t28) = 1;
    goto LAB11;

LAB12:    t33 = (t0 + 1048U);
    t34 = *((char **)t33);
    t33 = (t0 + 1208U);
    t35 = *((char **)t33);
    memset(t36, 0, 8);
    xsi_vlog_unsigned_add(t36, 32, t34, 32, t35, 32);
    goto LAB13;

LAB14:    t33 = (t0 + 1368U);
    t43 = *((char **)t33);
    t33 = ((char*)((ng2)));
    memset(t44, 0, 8);
    t45 = (t43 + 4);
    t46 = (t33 + 4);
    t47 = *((unsigned int *)t43);
    t48 = *((unsigned int *)t33);
    t49 = (t47 ^ t48);
    t50 = *((unsigned int *)t45);
    t51 = *((unsigned int *)t46);
    t52 = (t50 ^ t51);
    t53 = (t49 | t52);
    t54 = *((unsigned int *)t45);
    t55 = *((unsigned int *)t46);
    t56 = (t54 | t55);
    t57 = (~(t56));
    t58 = (t53 & t57);
    if (t58 != 0)
        goto LAB24;

LAB21:    if (t56 != 0)
        goto LAB23;

LAB22:    *((unsigned int *)t44) = 1;

LAB24:    memset(t42, 0, 8);
    t60 = (t44 + 4);
    t61 = *((unsigned int *)t60);
    t62 = (~(t61));
    t63 = *((unsigned int *)t44);
    t64 = (t63 & t62);
    t65 = (t64 & 1U);
    if (t65 != 0)
        goto LAB25;

LAB26:    if (*((unsigned int *)t60) != 0)
        goto LAB27;

LAB28:    t67 = (t42 + 4);
    t68 = *((unsigned int *)t42);
    t69 = *((unsigned int *)t67);
    t70 = (t68 || t69);
    if (t70 > 0)
        goto LAB29;

LAB30:    t105 = *((unsigned int *)t42);
    t106 = (~(t105));
    t107 = *((unsigned int *)t67);
    t108 = (t106 || t107);
    if (t108 > 0)
        goto LAB31;

LAB32:    if (*((unsigned int *)t67) > 0)
        goto LAB33;

LAB34:    if (*((unsigned int *)t42) > 0)
        goto LAB35;

LAB36:    memcpy(t41, t109, 8);

LAB37:    goto LAB15;

LAB16:    xsi_vlog_unsigned_bit_combine(t3, 32, t36, 32, t41, 32);
    goto LAB20;

LAB18:    memcpy(t3, t36, 8);
    goto LAB20;

LAB23:    t59 = (t44 + 4);
    *((unsigned int *)t44) = 1;
    *((unsigned int *)t59) = 1;
    goto LAB24;

LAB25:    *((unsigned int *)t42) = 1;
    goto LAB28;

LAB27:    t66 = (t42 + 4);
    *((unsigned int *)t42) = 1;
    *((unsigned int *)t66) = 1;
    goto LAB28;

LAB29:    t71 = (t0 + 1048U);
    t72 = *((char **)t71);
    t71 = (t0 + 1208U);
    t73 = *((char **)t71);
    t75 = *((unsigned int *)t72);
    t76 = *((unsigned int *)t73);
    t77 = (t75 & t76);
    *((unsigned int *)t74) = t77;
    t71 = (t72 + 4);
    t78 = (t73 + 4);
    t79 = (t74 + 4);
    t80 = *((unsigned int *)t71);
    t81 = *((unsigned int *)t78);
    t82 = (t80 | t81);
    *((unsigned int *)t79) = t82;
    t83 = *((unsigned int *)t79);
    t84 = (t83 != 0);
    if (t84 == 1)
        goto LAB38;

LAB39:
LAB40:    goto LAB30;

LAB31:    t111 = (t0 + 1368U);
    t112 = *((char **)t111);
    t111 = ((char*)((ng3)));
    memset(t113, 0, 8);
    t114 = (t112 + 4);
    t115 = (t111 + 4);
    t116 = *((unsigned int *)t112);
    t117 = *((unsigned int *)t111);
    t118 = (t116 ^ t117);
    t119 = *((unsigned int *)t114);
    t120 = *((unsigned int *)t115);
    t121 = (t119 ^ t120);
    t122 = (t118 | t121);
    t123 = *((unsigned int *)t114);
    t124 = *((unsigned int *)t115);
    t125 = (t123 | t124);
    t126 = (~(t125));
    t127 = (t122 & t126);
    if (t127 != 0)
        goto LAB44;

LAB41:    if (t125 != 0)
        goto LAB43;

LAB42:    *((unsigned int *)t113) = 1;

LAB44:    memset(t110, 0, 8);
    t129 = (t113 + 4);
    t130 = *((unsigned int *)t129);
    t131 = (~(t130));
    t132 = *((unsigned int *)t113);
    t133 = (t132 & t131);
    t134 = (t133 & 1U);
    if (t134 != 0)
        goto LAB45;

LAB46:    if (*((unsigned int *)t129) != 0)
        goto LAB47;

LAB48:    t136 = (t110 + 4);
    t137 = *((unsigned int *)t110);
    t138 = *((unsigned int *)t136);
    t139 = (t137 || t138);
    if (t139 > 0)
        goto LAB49;

LAB50:    t170 = *((unsigned int *)t110);
    t171 = (~(t170));
    t172 = *((unsigned int *)t136);
    t173 = (t171 || t172);
    if (t173 > 0)
        goto LAB51;

LAB52:    if (*((unsigned int *)t136) > 0)
        goto LAB53;

LAB54:    if (*((unsigned int *)t110) > 0)
        goto LAB55;

LAB56:    memcpy(t109, t174, 8);

LAB57:    goto LAB32;

LAB33:    xsi_vlog_unsigned_bit_combine(t41, 32, t74, 32, t109, 32);
    goto LAB37;

LAB35:    memcpy(t41, t74, 8);
    goto LAB37;

LAB38:    t85 = *((unsigned int *)t74);
    t86 = *((unsigned int *)t79);
    *((unsigned int *)t74) = (t85 | t86);
    t87 = (t72 + 4);
    t88 = (t73 + 4);
    t89 = *((unsigned int *)t72);
    t90 = (~(t89));
    t91 = *((unsigned int *)t87);
    t92 = (~(t91));
    t93 = *((unsigned int *)t73);
    t94 = (~(t93));
    t95 = *((unsigned int *)t88);
    t96 = (~(t95));
    t97 = (t90 & t92);
    t98 = (t94 & t96);
    t99 = (~(t97));
    t100 = (~(t98));
    t101 = *((unsigned int *)t79);
    *((unsigned int *)t79) = (t101 & t99);
    t102 = *((unsigned int *)t79);
    *((unsigned int *)t79) = (t102 & t100);
    t103 = *((unsigned int *)t74);
    *((unsigned int *)t74) = (t103 & t99);
    t104 = *((unsigned int *)t74);
    *((unsigned int *)t74) = (t104 & t100);
    goto LAB40;

LAB43:    t128 = (t113 + 4);
    *((unsigned int *)t113) = 1;
    *((unsigned int *)t128) = 1;
    goto LAB44;

LAB45:    *((unsigned int *)t110) = 1;
    goto LAB48;

LAB47:    t135 = (t110 + 4);
    *((unsigned int *)t110) = 1;
    *((unsigned int *)t135) = 1;
    goto LAB48;

LAB49:    t140 = (t0 + 1048U);
    t141 = *((char **)t140);
    t140 = (t0 + 1208U);
    t142 = *((char **)t140);
    t144 = *((unsigned int *)t141);
    t145 = *((unsigned int *)t142);
    t146 = (t144 | t145);
    *((unsigned int *)t143) = t146;
    t140 = (t141 + 4);
    t147 = (t142 + 4);
    t148 = (t143 + 4);
    t149 = *((unsigned int *)t140);
    t150 = *((unsigned int *)t147);
    t151 = (t149 | t150);
    *((unsigned int *)t148) = t151;
    t152 = *((unsigned int *)t148);
    t153 = (t152 != 0);
    if (t153 == 1)
        goto LAB58;

LAB59:
LAB60:    goto LAB50;

LAB51:    t176 = (t0 + 1368U);
    t177 = *((char **)t176);
    t176 = ((char*)((ng4)));
    memset(t178, 0, 8);
    t179 = (t177 + 4);
    t180 = (t176 + 4);
    t181 = *((unsigned int *)t177);
    t182 = *((unsigned int *)t176);
    t183 = (t181 ^ t182);
    t184 = *((unsigned int *)t179);
    t185 = *((unsigned int *)t180);
    t186 = (t184 ^ t185);
    t187 = (t183 | t186);
    t188 = *((unsigned int *)t179);
    t189 = *((unsigned int *)t180);
    t190 = (t188 | t189);
    t191 = (~(t190));
    t192 = (t187 & t191);
    if (t192 != 0)
        goto LAB64;

LAB61:    if (t190 != 0)
        goto LAB63;

LAB62:    *((unsigned int *)t178) = 1;

LAB64:    memset(t175, 0, 8);
    t194 = (t178 + 4);
    t195 = *((unsigned int *)t194);
    t196 = (~(t195));
    t197 = *((unsigned int *)t178);
    t198 = (t197 & t196);
    t199 = (t198 & 1U);
    if (t199 != 0)
        goto LAB65;

LAB66:    if (*((unsigned int *)t194) != 0)
        goto LAB67;

LAB68:    t201 = (t175 + 4);
    t202 = *((unsigned int *)t175);
    t203 = *((unsigned int *)t201);
    t204 = (t202 || t203);
    if (t204 > 0)
        goto LAB69;

LAB70:    t221 = *((unsigned int *)t175);
    t222 = (~(t221));
    t223 = *((unsigned int *)t201);
    t224 = (t222 || t223);
    if (t224 > 0)
        goto LAB71;

LAB72:    if (*((unsigned int *)t201) > 0)
        goto LAB73;

LAB74:    if (*((unsigned int *)t175) > 0)
        goto LAB75;

LAB76:    memcpy(t174, t225, 8);

LAB77:    goto LAB52;

LAB53:    xsi_vlog_unsigned_bit_combine(t109, 32, t143, 32, t174, 32);
    goto LAB57;

LAB55:    memcpy(t109, t143, 8);
    goto LAB57;

LAB58:    t154 = *((unsigned int *)t143);
    t155 = *((unsigned int *)t148);
    *((unsigned int *)t143) = (t154 | t155);
    t156 = (t141 + 4);
    t157 = (t142 + 4);
    t158 = *((unsigned int *)t156);
    t159 = (~(t158));
    t160 = *((unsigned int *)t141);
    t161 = (t160 & t159);
    t162 = *((unsigned int *)t157);
    t163 = (~(t162));
    t164 = *((unsigned int *)t142);
    t165 = (t164 & t163);
    t166 = (~(t161));
    t167 = (~(t165));
    t168 = *((unsigned int *)t148);
    *((unsigned int *)t148) = (t168 & t166);
    t169 = *((unsigned int *)t148);
    *((unsigned int *)t148) = (t169 & t167);
    goto LAB60;

LAB63:    t193 = (t178 + 4);
    *((unsigned int *)t178) = 1;
    *((unsigned int *)t193) = 1;
    goto LAB64;

LAB65:    *((unsigned int *)t175) = 1;
    goto LAB68;

LAB67:    t200 = (t175 + 4);
    *((unsigned int *)t175) = 1;
    *((unsigned int *)t200) = 1;
    goto LAB68;

LAB69:    t205 = (t0 + 1048U);
    t206 = *((char **)t205);
    t205 = (t0 + 1208U);
    t207 = *((char **)t205);
    t209 = *((unsigned int *)t206);
    t210 = *((unsigned int *)t207);
    t211 = (t209 ^ t210);
    *((unsigned int *)t208) = t211;
    t205 = (t206 + 4);
    t212 = (t207 + 4);
    t213 = (t208 + 4);
    t214 = *((unsigned int *)t205);
    t215 = *((unsigned int *)t212);
    t216 = (t214 | t215);
    *((unsigned int *)t213) = t216;
    t217 = *((unsigned int *)t213);
    t218 = (t217 != 0);
    if (t218 == 1)
        goto LAB78;

LAB79:
LAB80:    goto LAB70;

LAB71:    t227 = (t0 + 1368U);
    t228 = *((char **)t227);
    t227 = ((char*)((ng5)));
    memset(t229, 0, 8);
    t230 = (t228 + 4);
    t231 = (t227 + 4);
    t232 = *((unsigned int *)t228);
    t233 = *((unsigned int *)t227);
    t234 = (t232 ^ t233);
    t235 = *((unsigned int *)t230);
    t236 = *((unsigned int *)t231);
    t237 = (t235 ^ t236);
    t238 = (t234 | t237);
    t239 = *((unsigned int *)t230);
    t240 = *((unsigned int *)t231);
    t241 = (t239 | t240);
    t242 = (~(t241));
    t243 = (t238 & t242);
    if (t243 != 0)
        goto LAB84;

LAB81:    if (t241 != 0)
        goto LAB83;

LAB82:    *((unsigned int *)t229) = 1;

LAB84:    memset(t226, 0, 8);
    t245 = (t229 + 4);
    t246 = *((unsigned int *)t245);
    t247 = (~(t246));
    t248 = *((unsigned int *)t229);
    t249 = (t248 & t247);
    t250 = (t249 & 1U);
    if (t250 != 0)
        goto LAB85;

LAB86:    if (*((unsigned int *)t245) != 0)
        goto LAB87;

LAB88:    t252 = (t226 + 4);
    t253 = *((unsigned int *)t226);
    t254 = *((unsigned int *)t252);
    t255 = (t253 || t254);
    if (t255 > 0)
        goto LAB89;

LAB90:    t260 = *((unsigned int *)t226);
    t261 = (~(t260));
    t262 = *((unsigned int *)t252);
    t263 = (t261 || t262);
    if (t263 > 0)
        goto LAB91;

LAB92:    if (*((unsigned int *)t252) > 0)
        goto LAB93;

LAB94:    if (*((unsigned int *)t226) > 0)
        goto LAB95;

LAB96:    memcpy(t225, t264, 8);

LAB97:    goto LAB72;

LAB73:    xsi_vlog_unsigned_bit_combine(t174, 32, t208, 32, t225, 32);
    goto LAB77;

LAB75:    memcpy(t174, t208, 8);
    goto LAB77;

LAB78:    t219 = *((unsigned int *)t208);
    t220 = *((unsigned int *)t213);
    *((unsigned int *)t208) = (t219 | t220);
    goto LAB80;

LAB83:    t244 = (t229 + 4);
    *((unsigned int *)t229) = 1;
    *((unsigned int *)t244) = 1;
    goto LAB84;

LAB85:    *((unsigned int *)t226) = 1;
    goto LAB88;

LAB87:    t251 = (t226 + 4);
    *((unsigned int *)t226) = 1;
    *((unsigned int *)t251) = 1;
    goto LAB88;

LAB89:    t256 = (t0 + 1208U);
    t257 = *((char **)t256);
    t256 = (t0 + 1048U);
    t258 = *((char **)t256);
    memset(t259, 0, 8);
    xsi_vlog_unsigned_rshift(t259, 32, t257, 32, t258, 32);
    goto LAB90;

LAB91:    t256 = (t0 + 1368U);
    t266 = *((char **)t256);
    t256 = ((char*)((ng6)));
    memset(t267, 0, 8);
    t268 = (t266 + 4);
    t269 = (t256 + 4);
    t270 = *((unsigned int *)t266);
    t271 = *((unsigned int *)t256);
    t272 = (t270 ^ t271);
    t273 = *((unsigned int *)t268);
    t274 = *((unsigned int *)t269);
    t275 = (t273 ^ t274);
    t276 = (t272 | t275);
    t277 = *((unsigned int *)t268);
    t278 = *((unsigned int *)t269);
    t279 = (t277 | t278);
    t280 = (~(t279));
    t281 = (t276 & t280);
    if (t281 != 0)
        goto LAB101;

LAB98:    if (t279 != 0)
        goto LAB100;

LAB99:    *((unsigned int *)t267) = 1;

LAB101:    memset(t265, 0, 8);
    t283 = (t267 + 4);
    t284 = *((unsigned int *)t283);
    t285 = (~(t284));
    t286 = *((unsigned int *)t267);
    t287 = (t286 & t285);
    t288 = (t287 & 1U);
    if (t288 != 0)
        goto LAB102;

LAB103:    if (*((unsigned int *)t283) != 0)
        goto LAB104;

LAB105:    t290 = (t265 + 4);
    t291 = *((unsigned int *)t265);
    t292 = *((unsigned int *)t290);
    t293 = (t291 || t292);
    if (t293 > 0)
        goto LAB106;

LAB107:    t298 = *((unsigned int *)t265);
    t299 = (~(t298));
    t300 = *((unsigned int *)t290);
    t301 = (t299 || t300);
    if (t301 > 0)
        goto LAB108;

LAB109:    if (*((unsigned int *)t290) > 0)
        goto LAB110;

LAB111:    if (*((unsigned int *)t265) > 0)
        goto LAB112;

LAB113:    memcpy(t264, t302, 8);

LAB114:    goto LAB92;

LAB93:    xsi_vlog_unsigned_bit_combine(t225, 32, t259, 32, t264, 32);
    goto LAB97;

LAB95:    memcpy(t225, t259, 8);
    goto LAB97;

LAB100:    t282 = (t267 + 4);
    *((unsigned int *)t267) = 1;
    *((unsigned int *)t282) = 1;
    goto LAB101;

LAB102:    *((unsigned int *)t265) = 1;
    goto LAB105;

LAB104:    t289 = (t265 + 4);
    *((unsigned int *)t265) = 1;
    *((unsigned int *)t289) = 1;
    goto LAB105;

LAB106:    t294 = (t0 + 1208U);
    t295 = *((char **)t294);
    t294 = (t0 + 1048U);
    t296 = *((char **)t294);
    memset(t297, 0, 8);
    xsi_vlog_unsigned_lshift(t297, 32, t295, 32, t296, 32);
    goto LAB107;

LAB108:    t294 = (t0 + 1368U);
    t304 = *((char **)t294);
    t294 = ((char*)((ng7)));
    memset(t305, 0, 8);
    t306 = (t304 + 4);
    t307 = (t294 + 4);
    t308 = *((unsigned int *)t304);
    t309 = *((unsigned int *)t294);
    t310 = (t308 ^ t309);
    t311 = *((unsigned int *)t306);
    t312 = *((unsigned int *)t307);
    t313 = (t311 ^ t312);
    t314 = (t310 | t313);
    t315 = *((unsigned int *)t306);
    t316 = *((unsigned int *)t307);
    t317 = (t315 | t316);
    t318 = (~(t317));
    t319 = (t314 & t318);
    if (t319 != 0)
        goto LAB118;

LAB115:    if (t317 != 0)
        goto LAB117;

LAB116:    *((unsigned int *)t305) = 1;

LAB118:    memset(t303, 0, 8);
    t321 = (t305 + 4);
    t322 = *((unsigned int *)t321);
    t323 = (~(t322));
    t324 = *((unsigned int *)t305);
    t325 = (t324 & t323);
    t326 = (t325 & 1U);
    if (t326 != 0)
        goto LAB119;

LAB120:    if (*((unsigned int *)t321) != 0)
        goto LAB121;

LAB122:    t328 = (t303 + 4);
    t329 = *((unsigned int *)t303);
    t330 = *((unsigned int *)t328);
    t331 = (t329 || t330);
    if (t331 > 0)
        goto LAB123;

LAB124:    t336 = *((unsigned int *)t303);
    t337 = (~(t336));
    t338 = *((unsigned int *)t328);
    t339 = (t337 || t338);
    if (t339 > 0)
        goto LAB125;

LAB126:    if (*((unsigned int *)t328) > 0)
        goto LAB127;

LAB128:    if (*((unsigned int *)t303) > 0)
        goto LAB129;

LAB130:    memcpy(t302, t332, 8);

LAB131:    goto LAB109;

LAB110:    xsi_vlog_unsigned_bit_combine(t264, 32, t297, 32, t302, 32);
    goto LAB114;

LAB112:    memcpy(t264, t297, 8);
    goto LAB114;

LAB117:    t320 = (t305 + 4);
    *((unsigned int *)t305) = 1;
    *((unsigned int *)t320) = 1;
    goto LAB118;

LAB119:    *((unsigned int *)t303) = 1;
    goto LAB122;

LAB121:    t327 = (t303 + 4);
    *((unsigned int *)t303) = 1;
    *((unsigned int *)t327) = 1;
    goto LAB122;

LAB123:    t332 = (t0 + 1048U);
    t333 = *((char **)t332);
    t332 = (t0 + 1208U);
    t334 = *((char **)t332);
    memset(t335, 0, 8);
    xsi_vlog_unsigned_minus(t335, 32, t333, 32, t334, 32);
    goto LAB124;

LAB125:    t332 = ((char*)((ng8)));
    goto LAB126;

LAB127:    xsi_vlog_unsigned_bit_combine(t302, 32, t335, 32, t332, 32);
    goto LAB131;

LAB129:    memcpy(t302, t335, 8);
    goto LAB131;

}


extern void work_m_00000000001422232904_2725559894_init()
{
	static char *pe[] = {(void *)Cont_28_0};
	xsi_register_didat("work_m_00000000001422232904_2725559894", "isim/cpu_t_isim_beh.exe.sim/work/m_00000000001422232904_2725559894.didat");
	xsi_register_executes(pe);
}
